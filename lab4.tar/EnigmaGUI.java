public class EnigmaGUI {

    public static void main(String[] args) {
        EnigmaFrame u = new EnigmaFrame();
        u.setVisible(true);
    }
}
